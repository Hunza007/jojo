# Simple React Hello World

Run these commands:

```
npm i
npm start
```

You only have to run `npm i` the first time.

In a separate window, run `npm run watch` to hot-reload your changes.
